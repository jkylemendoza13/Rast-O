<?php 

$connect = mysqli_connect('localhost','root','','maxicooldb');

if($connect){
	
}
else{
	echo 'failed';
}
?>