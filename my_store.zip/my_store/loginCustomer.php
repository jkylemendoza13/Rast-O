<?php

include 'conn.php';


$email = $_POST["email"];
$password = $_POST["password"];

$user = $connect->query("SELECT c_id FROM customer WHERE c_email = '".$email."' AND c_pass = '".$password."'");

$userID = '';

while($fetchData = $user->fetch_assoc()){
  $userID = $fetchData['c_id'];
}

echo json_encode(mysqli_num_rows($user) == 1 ? $userID : '0');

 ?>
