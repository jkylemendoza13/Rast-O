<?php
include 'conn.php';

$order_id = $_POST["order_id"];

$queryResult = $connect->query("SELECT * FROM order_details WHERE order_id = '".$order_id."'");

$result = array();

while($fetchData = $queryResult->fetch_assoc()){
	$result[] = $fetchData;
}

echo json_encode($result);

?>