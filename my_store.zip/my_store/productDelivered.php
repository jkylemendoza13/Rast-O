<?php
include 'conn.php';

date_default_timezone_set('Asia/Hong_Kong');

$orderID = $_POST["order_id"];
$qrCode = $_POST["qrCode"];

$timeDelivered = date('Y-m-d H:i:s');

$queryResult = $connect->query("UPDATE orders SET status = 1,delivery_time='".$timeDelivered."'  WHERE id = '".$orderID."' AND qr_code = '".$qrCode."'");

?>