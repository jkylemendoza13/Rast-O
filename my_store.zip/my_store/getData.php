<?php
include 'conn.php';

$driverID = $_POST["driver_id"];

$queryResult = $connect->query("SELECT orders.id,orders.driver_id,orders.customer_phone_number,orders.qr_code,orders.place,orders.status,CONCAT(customer.cf_name,' ',customer.cl_name) as 'customer' FROM orders INNER JOIN customer ON orders.customer_id = customer.c_id WHERE driver_id = '".$driverID."' ORDER BY id");

$result = array();

while($fetchData = $queryResult->fetch_assoc()){
	$result[] = $fetchData;
}

echo json_encode($result);

?>