<?php
include 'conn.php';

date_default_timezone_set('Asia/Hong_Kong');

$orderID = $_POST["order_id"];
$lat = $_POST["latitude"];
$lng = $_POST["longitude"];
$status = $_POST["status"];
$timeReport = date('Y-m-d H:i:s');
$queryResult = $connect->query("INSERT INTO coordinates(id,order_id,latitude,longitude,report_time,status) VALUES(null,'".$orderID."','".$lat."','".$lng."','".$timeReport."','".$status."')");