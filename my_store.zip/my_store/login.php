<?php

include 'conn.php';


$email = $_POST["email"];
$password = md5($_POST["password"]);
$userType = $_POST["type"];

$user = $connect->query("SELECT id FROM users WHERE email = '".$email."' AND password = '".$password."' AND type = '".$userType."'");

$userID = '';

while($fetchData = $user->fetch_assoc()){
  $userID = $fetchData['id'];
}

echo json_encode(mysqli_num_rows($user) == 1 ? $userID : '0');

 ?>
