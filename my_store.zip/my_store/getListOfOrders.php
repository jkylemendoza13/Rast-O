<?php
include 'conn.php';

$customer_id = $_POST["customer_id"];

$queryResult = $connect->query("SELECT * FROM orders WHERE customer_id = '".$customer_id."'");

$result = array();

while($fetchData = $queryResult->fetch_assoc()){
	$result[] = $fetchData;
}

echo json_encode($result);

?>