<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Products extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin')) { 
            redirect('login');
        }
		
		$this->load->model('model_product');
        $this->load->model('model_manufacturer');
        $this->load->model('model_product_model');
	}

	public function index()
	{
        $data['udata']=$this->session->userdata;
        $data['products'] = $this->model_product->getAll();
        $data['manufacturers'] = $this->model_manufacturer->getAllManufacturers();
        $data['models'] = $this->model_product_model->getAllModels();
        
        //$this->load->view('view_product', $data); 
        $this->parser->parse('admin/view_products', $data);   
    }


	public function sell()
	{
        if ($this->input->server('REQUEST_METHOD') == 'POST'){	
            $cid = $this->input->post('product_id');
            $cdata['cid'] = $cid;
            if(!$this->input->post('buttonSubmits'))
    		{
    			$data['message'] = '';
                //$data['vRow'] = $this->model_product->get($cid);
                $this->load->view('admin/view_sell', $cdata);
    		}
            else{
                $this->form_validation->set_rules('cf_name', 'First Name', 'required');
                $this->form_validation->set_rules('cl_name', 'Last Name', 'required');
                $this->form_validation->set_rules('c_email', 'Email', 'required|valid_email');
                $this->form_validation->set_rules('c_mobile', 'Mobile', 'required|trim');
                $this->form_validation->set_rules('s_price', 'Selling Price', 'required|numeric|greater_than[1]');
                $this->form_validation->set_rules('w_end', 'Warranty End date', 'required');
				$this->form_validation->set_rules('p_id', 'Product Id', 'required');
                
                if ($this->form_validation->run() == FALSE) {
                    $data['vRow'] = $this->model_products->get($cid);
                    $this->load->view('admin/view_sell', $data);
                }
                else {
                    $p_id = $this->input->post('p_id');
                    $cf_name = $this->input->post('cf_name');
                    $cl_name = $this->input->post('cl_name');
                    $c_email = $this->input->post('c_email');
                    $s_price = $this->input->post('s_price');
                    $c_mobile = $this->input->post('c_mobile');
                    $w_start = $this->input->post('w_start');
                    $w_end = $this->input->post('w_end');
                    $payment_type = $this->input->post('payment_type');
                    $c_pass = "1234";

                    $this->model_product->sell($p_id,$cf_name,$cl_name,$c_email,$s_price,$c_mobile,$w_start,$w_end,$payment_type,$c_pass);
                    redirect(base_url('admin/products'));
                }
            }
        }
        else {
            redirect(base_url('admin/products'));
        }
	}

	public function add()
	{	
		if($this->input->post('buttonSubmit')) {
			$data['message'] = '';
		


				$this->form_validation->set_rules('manufacturer_id', 'Manufacturer', 'required');
				$this->form_validation->set_rules('model_id', 'Model', 'required');
				$this->form_validation->set_rules('category', 'Category ', 'required');
				$this->form_validation->set_rules('b_price', 'Buying Price ', 'required');
				
				$this->form_validation->set_rules('add_date', 'Adding Date', 'required');
				
				$this->form_validation->set_rules('product_name', 'Product Name', 'required');
					
				
				if($this->form_validation->run() == FALSE)
				{
					//$data['vRow'] = $this->model_product->get($cid);
                    $this->load->view('admin/view_products');
				}
				else{
					
		
            $config['upload_path']          = './uploads/';
            $config['allowed_types']        = 'gif|jpg|png';
            $config['max_width']    = '2048';
            $config['max_height']   = '2048';
            $this->load->library('upload', $config);
            
            
            $manufacturer_name = $this->input->post('manufacturer_id');
		    $model_name = $this->input->post('model_id');
            $category = $this->input->post('category');
            $b_price = $this->input->post('b_price');
        
            
            $add_date = $this->input->post('add_date');
            $status = "available";
            
            $product_name = $this->input->post('product_name');

            $u_id = $this->session->userdata('id');
           
            $featured = $this->input->post('featured');
            
            $this->upload->do_upload('image');
            $data = $this->upload->data('image');
            $image= $data['file_name']; 
			
            $this->model_product->insert($featured,$image,$manufacturer_name,$model_name,$category,$b_price,$add_date,$status,$product_name,$u_id);
			$this->session->set_flashdata('message','Product Successfully Created.');
			redirect(base_url('admin/products'));
		
			}
		}
		else{
		redirect(base_url('admin/products'));
		}
	}



	public function DeleteProduct()
	{
        if ($this->input->server('REQUEST_METHOD') == 'POST'){	
             
            $id = $this->input->post('product_id');
            $this->model_product->delete($id);
			$this->session->set_flashdata('message','Product Successfully Deleted.');
            redirect(base_url('admin/products'));
        }
        else {
            redirect(base_url('admin/products'));
	    }
    }
        
    public function DeleteCustomer()
	{	
        if ($this->input->server('REQUEST_METHOD') == 'POST'){	
            $p_id= $this->input->post('p_id');
            $c_id= $this->input->post('c_id');
               
            $this->model_product->deletecustomer($c_id,$p_id);
			$this->session->set_flashdata('message','Customer Successfully Created.');
            redirect(base_url('admin/products/soldlist'));
        }
        else{
            redirect(base_url('admin/products/soldlist'));
        }
	}

    public function soldList()
    {   
        $data['cus'] = $this->model_product->customerList();
        $this->load->view('admin/view_sold', $data);     
    }
}

