<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin')) { 
            redirect('login');
        }
		
		$this->load->model('model_product');
        $this->load->model('model_manufacturer');
        $this->load->model('model_product_model');
        $this->load->model('model_employee');
        $this->load->model('model_orders');
	}



	public function index()
	{      
        $data['products'] = $this->model_orders->getSoldOrders();
        $data['customers'] = $this->model_product->customerList();
        $data['manufacturers_group'] = $this->model_product->getAllByManufacturer();
        $data['manufacturers_group_sold'] = $this->model_product->getAllByManufacturerSold();
        
        // $data['product_by_month'] = $this->model_product->get_product_by_month();

        $data['employees'] = $this->model_employee->getAll();
    	$data['user'] = $this->session->userdata;

    	// die(var_dump($data['manufacturers_group']));
        

    	$this->parser->parse('admin/view_index', $data);
	}

	public function logout()
	{

	       $this->session->sess_destroy();
	       redirect('login');
	}

    public function summaryofReports(){
        $this->load->view('admin/summaryofReports');

        $html = $this->output->get_output();
        
        // Load pdf library
        $this->load->library('pdf');
        
        // Load HTML content
        $this->dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation
        $this->dompdf->setPaper('Legal', 'landscape');
        
        // Render the HTML as PDF
        $this->dompdf->render();
        
        // Output the generated PDF (1 = download and 0 = preview)
        $this->dompdf->stream("welcome.pdf", array("Attachment"=>0));
    }

    public function save_img(){
        $data = $this->input->post('hid_img');
        $file = 'summary.png';

        // remove "data:image/png;base64,"
        $uri =  substr($data,strpos($data,",")+1);

        // save to file in uploads folder of codeigniter
        file_put_contents('./reports/'.$file, base64_decode($uri));
    }


}
