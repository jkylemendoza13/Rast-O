<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin')) { 
            redirect('login');
        }
        $this->load->model('model_orders');
	}

	public function removeOrder(){
		$id = $this->uri->segment(4);
		$this->model_orders->removeOrder($this->uri->segment(4));
		$this->session->set_flashdata('msg', 'Remove Order!');
		redirect('admin/orders/orderListAdminSide');
	}

	public function receipt(){
		$qrCode = $this->model_orders->getQRCODE($this->uri->segment(4));
		$data['order_details'] = $this->model_orders->getOrderDetails($this->uri->segment(4));
		$data['qrCode'] = $qrCode;
		$data['user_details'] = $this->model_orders->getSpecifiOrderDetails($this->uri->segment(4));
		$data['driver_details'] = $this->model_orders->getOrderDriver($this->uri->segment(4));
		$this->load->view('welcome_message',$data);

        
        // Get output html
        $html = $this->output->get_output();
        
        // Load pdf library
        $this->load->library('pdf');
        
        // Load HTML content
        $this->dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation
        $this->dompdf->setPaper('A4', 'portrait');
        
        // Render the HTML as PDF
        $this->dompdf->render();
        
        // Output the generated PDF (1 = download and 0 = preview)
        $this->dompdf->stream("welcome.pdf", array("Attachment"=>0));
	}

	public function index()
	{
    	$this->load->view('public/search_order');
	}

	public function addOrders(){
		$this->load->library('ciqrcode');
		$qrCode = $this->model_orders->addOrder();

		$params['data'] = $qrCode;
		$params['size'] = 10;
		$params['savename'] = FCPATH.'/qrcodes/'.$qrCode.'.png';
		$this->ciqrcode->generate($params);
		redirect('admin/orders/viewHistoryTransactions');
	}

	public function viewHistoryTransactions(){
		$data["orders"] = $this->model_orders->getORDERS();
		$this->load->view('public/viewHistoryTransactions',$data);
	}

	public function viewOrderDetails(){
		$order_id = $this->input->post('id');
		$data["order_details"] = $this->model_orders->getOrderDetails($order_id);
		$this->load->view('public/viewDetailOrders',$data);	
	}

	//change niyo yung table ng pagfefetch
	public function orderProducts(){
		$data["product"] = $this->model_orders->order_products();
		$data["temp_orders"] = $this->model_orders->get_temporary_orders();
		$this->load->view('public/order_products',$data);	
	}

	public function addProductOrder(){
		$this->model_orders->add_product_order($_POST["product_id"],$_POST["product_name"],$_POST["product_price"],$_POST["quantity"],$_POST["manufacturerid"]);
		echo $this->viewTemporaryOrders();
	}

	public function load(){
		echo $this->viewTemporaryOrders();	
	}

	public function removeProduct(){
		$this->model_orders->removeTemporaryOrder($_POST["row_id"]);
		echo $this->viewTemporaryOrders();
	}

	public function clear(){
		$this->model_orders->clearCart();
		echo $this->viewTemporaryOrders();
	}	

	public function viewTemporaryOrders(){
		setlocale(LC_MONETARY,"en_PH");
		$temp_orders = $this->model_orders->get_temporary_orders();

		$output = '';
		$output .= '
			<h3>Cart Orders</h3>
			<div class="table-responsive">
				<div align="right">
					<button type="button" id="clear_cart" class="btn btn-warning">
						Clear Cart
					</button>
				</div>
				<br />
				<table class="table table-bordered">
					<tr>
						<th width="40%">Name</th>
						<th width="15%">Quantity</th>
						<th width="15%">Price</th>
						<th width="15%">Total</th>
						<th width="15%">Action</th>
					</tr>
		';
		$count = 0;
		$total = 0;
		foreach($temp_orders as $orders){
			$count++;
			$total += ($orders->product_price * $orders->product_quantity) ;
			$output .= '
				<tr>
					<td>'.$orders->product_name.'</td>
					<td>'.$orders->product_quantity.'</td>
					<td>'.number_format($orders->product_price,2).'</td>
					<td>'.number_format(($orders->product_price * $orders->product_quantity),2).'</td>
					<td>
						<button type="button" name="remove" class="btn btn-danger btn-xs remove_inventory" id="'.$orders->id.'">
						Remove
						</button>
					</td>
				</tr>
			';
		}
		$output .= '
				<tr>
					<td colspan="4" align="right">Total</td>
					<td>'.number_format($total,2).'</td>
				</tr>
			</table>';
			if(count($temp_orders) > 0){
		$output .= '
				<div>
					<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Order Now</button>

					<!-- Modal -->
					<div id="myModal" class="modal fade" role="dialog">
					  <div class="modal-dialog">

					    <!-- Modal content-->
					    <div class="modal-content">
					      <div class="modal-header">
					        <button type="button" class="close" data-dismiss="modal">&times;</button>
					        <h4 class="modal-title">Total Cost</h4>
					      </div>
					      <div class="modal-body">
					      <table class="table table-bordered">
					<tr>
						<th width="40%">Name</th>
						<th width="15%">Quantity</th>
						<th width="15%">Price</th>
						<th width="15%">Total</th>
					</tr>
		';
		$count = 0;
		$total = 0;
		foreach($temp_orders as $orders){
			$count++;
			$total += ($orders->product_price * $orders->product_quantity) ;
			$output .= '
				<tr>
					<td>'.$orders->product_name.'</td>
					<td>'.$orders->product_quantity.'</td>
					<td>'.number_format($orders->product_price,2).'</td>
					<td>'.number_format(($orders->product_price * $orders->product_quantity),2).'</td>
				</tr>
			';
		}
		$output .= '
				<tr>
					<td colspan="3" align="right">Total</td>
					<td>'.number_format($total,2).'</td>
				</tr>
			</table>
			Delivery Address : '.$this->session->userdata('address').'</br></br>
			<input type="checkbox" class="checkbox" id="checkTerms"><a data-toggle="modal" data-target="#myTermsandConditions">I agree with the terms and conditions</a></br></br></br>
			<a href="'.base_url().'admin/orders/addOrders" class="btn btn-danger" disabled="disabled" id="confirm_deliver">Check Out</a>
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					      </div>
					    </div>

					    <div id="myTermsandConditions" class="modal fade terms" role="dialog">
		  <div class="modal-dialog" style="width: 360px;">

		    <!-- Modal content-->
		    <div class="modal-content">
		      <div class="modal-header">
		        <h4 class="modal-title">How to deposit Cash to MaxiCool?</h4>
		      </div>
		      <div class="modal-body">
		        <p>1. Go to the nearest BDO Bank.</p>
		        <p>2. Fill out the deposit slip.</p>
		        <p>Here is our bank information.</p>
		        <p>-Account Name: MaxiCool Industry and Corporation</p>
		        <p>-Account Number: 506 0000 5162</p>
		        <p>3. Pay the total price of your order.</p>
		        <p>4. Send the deposit slip to maxicool@gmail.com</p>
		        <p>5. Wait for the other confirmation.</p></br>
				<p>Note: If you fail to pay within 48hrs your order has been deleted.</p>
				<p>We will send an order confirmation within 2-3 days once you paid.</p>		        
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-default" id="termClosed">Close</button>
		      </div>
		    </div>

		  </div>
		</div>

					  </div>
					</div>
				</div>';
			}
		$output .= '<div/>';

		if($count == 0){
			$output = '<h3 align="center">Cart is Empty</h3>';
		}
		return $output;
	}

	public function showOrderDetails(){
		$this->load->model('model_orders');
		$this->load->library('ciqrcode');
		$this->load->helper('toago_helper');

		$search_order_number = $this->input->post('search');
		$data['order'] = $this->model_orders->searchORDER_number($search_order_number);
		$data['coordinates'] = $this->model_orders->getCoordinates($data['order']['id']);
		$data['lastLocation'] = $this->model_orders->getLastKnownLocation($data['order']['id']);
		$data['firstLocation'] = $this->model_orders->getFirstLocation($data['order']['id']);

		$this->parser->parse('public/order_result', $data);
	}

	//ORDERS ADMIN SIDE
	public function orderListAdminSide(){
		$this->load->model("model_employee");
		$data['drivers'] = $this->model_employee->getDrivers();
		$data['driver_per_order'] = $this->model_employee->getOrderPerDriver();
		$data['orders'] = $this->model_orders->getAllORDERS();
		$data['type'] = 0;

		$this->load->view('admin/view_orders',$data);
	}
	public function pendingList(){
		$this->load->model("model_employee");
		$data['drivers'] = $this->model_employee->getDrivers();
		$data['driver_per_order'] = $this->model_employee->getOrderPerDriver();
		$data['orders'] = $this->model_orders->getPending();
		$data['type'] = 1;

		$this->load->view('admin/view_orders',$data);
	}
	public function deliveredList(){
		$this->load->model("model_employee");
		$data['drivers'] = $this->model_employee->getDrivers();
		$data['driver_per_order'] = $this->model_employee->getOrderPerDriver();
		$data['orders'] = $this->model_orders->getDelivered();
		$data['type'] = 2;

		$this->load->view('admin/view_orders',$data);
	}
	public function addToDriver(){
		$this->model_orders->addToDriver();
		$this->session->set_flashdata('msg', 'Order Added to Driver!');
		redirect('admin/orders/orderListAdminSide');
	}

	public function report(){
		$data['orders'] = $this->uri->segment(4) == 0 ? $this->model_orders->getAllORDERS() : ($this->uri->segment(4) == 1 ? $this->model_orders->getPending() : $this->model_orders->getDelivered());
		$data['type'] = $this->uri->segment(4);
		$this->load->view('admin/reports',$data);

		// Get output html
        $html = $this->output->get_output();
        
        // Load pdf library
        $this->load->library('pdf');
        
        // Load HTML content
        $this->dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation
        $this->dompdf->setPaper('A4', 'landscape');
        
        // Render the HTML as PDF
        $this->dompdf->render();
        
        // Output the generated PDF (1 = download and 0 = preview)
        $this->dompdf->stream("welcome.pdf", array("Attachment"=>0));
	}
}
