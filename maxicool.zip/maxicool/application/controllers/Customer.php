<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        if ( ! $this->session->userdata('isLogin')) { 
        	redirect('login/login_customer');
        }
		
		$this->load->model('model_product');
        $this->load->model('model_manufacturer');
        $this->load->model('model_product_model');
	}

	public function index()
	{	
		$data['products'] = $this->model_product->getLatest();
		$data['featured'] = $this->model_product->getFeatured();
		$data['manufacturers'] = $this->model_manufacturer->getAllManufacturers();
		$data['models'] = $this->model_product_model->getAllModels();
		
		$this->parser->parse('public/view_index', $data);
	}

	public function profile(){
		$this->load->view('public/customerProfile');
	}

	public function updateProfile(){
		$this->load->model('model_customer');
		$this->model_customer->updateProfile();
		$this->session->set_flashdata('msg', 'Updated Changes!');
		redirect('customer/profile');
	}

	public function userChangePassword(){
		$this->load->model('model_customer');
		$this->model_customer->changePassword();
		$this->session->set_flashdata('msg_password', 'Password Change Successfully!');
		redirect('customer/profile');
	}

}
