<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{	
        $session = $this->session->userdata('isLogin');

        if($session == FALSE) {
            $this->load->view('view_login');
        } else {
            redirect('admin/dashboard');
        }
	}

    public function glenwin(){
        $this->load->view('glenwin.php');
    }

    public function login_customer()
    {   
        $session = $this->session->userdata('isLogin');

        if($session == FALSE) {
            $this->load->view('public/login_customer');
        } else {
            redirect('customer');
        }
    }

    public function signUp(){
        $this->load->view('public/sign_customer');
    }

    public function signUpProcess(){
        $this->load->model('model_customer');
        $ifExisting = $this->model_customer->checkEmail();
        if($ifExisting == 1){
            $this->session->set_flashdata('email_error', 'Email already exists!');
            redirect('login/signUp');
        }
        else{
            $temppassword = $this->model_customer->signUpCustomer();
            $name = $this->input->post('f_name').' '.$this->input->post('l_name');
            $email = $this->input->post('u_email');
            $this->php_mail($name,$email,$temppassword);
        }
    }   
    public function php_mail($name,$email,$temppassword)
    {   
            require 'vendor/autoload.php';

            $mail = new PHPMailer;

            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 587;
            $mail->SMTPSecure = 'tls';
            $mail->SMTPAuth = true;
            $mail->Username = "inqueriesmaxicool@gmail.com";
            $mail->Password = "m@x1C00l_admin";
            $mail->isHTML(true);
            $mail->CharSet = "text/html; charset=UTF-8;";
            
            $mail->setFrom("inqueriesmaxicool@gmail.com","MaxiCool");

            $mail->addReplyTo("inqueriesmaxicool@gmail.com","MaxiCool");

            $mail->addAddress($email,$name);

            $mail->Subject = 'Welcome to MaxiCool';

            $data['name'] = $name;
            $data['temppassword'] = $temppassword;

            $mail->Body = $this->load->view('public/mailbody',$data, TRUE);

            //$mail->AltBody = 'This is a plain-text message body';

            if (!$mail->send()) {
                echo "Mailer Error: " . $mail->ErrorInfo;
            } else {
                $data['message'] = 'Check your email for your password';
                $this->load->view('public/login_customer',$data);
            }
}

    //just to check if empty, if not then verify function call and verified hoile returns to this function
    public function checklogin() {   // fields name, Boxes name to show, the checks functions
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|callback_verifylogin');
        
        if($this->form_validation->run() == FALSE) {
            $this->load->view('view_login');
        } 
        else {
            redirect('admin/dashboard');
        }
    }

    public function checkloginCustomer() {   // fields name, Boxes name to show, the checks functions
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|callback_verifyloginCustomer');
        
        if($this->form_validation->run() == FALSE) {
            $this->load->view('public/login_customer');
        } 
        else {
            redirect('customer');
        }
    }
        
        
    public function verifylogin() {
        $email= $this->input->post('email');
        $password= md5($this->input->post('password'));
        
        //Load the Login model for database check
        $this->load->model('model_login');
        $result= $this->model_login->login($email,$password);
        
        if($result){
            foreach ($result as $user){
                $s = array();
                $s['id'] = $user->id;
                $s['first_name'] = $user->first_name;
                $s['last_name'] = $user->last_name;
                $s['email'] = $user->email;
                $s['position'] = $user->position;
                $s['type'] = $user->type;
                $s['isLogin'] = 'true';

                $this->session->set_userdata($s);
            }

            return true;
        
        } else {
            $this->form_validation->set_message('verifylogin', 'Incorrect Login credentials');
            return false;
        }
    }

    public function verifyloginCustomer() {
        $email= $this->input->post('email');
        $password= md5($this->input->post('password'));
        
        //Load the Login model for database check
        $this->load->model('model_login');
        $result= $this->model_login->validateLoginCustomer($email,$password);
        
        if($result){
            foreach ($result as $user){
                $s = array();
                $s['id'] = $user->c_id;
                $s['first_name'] = $user->cf_name;
                $s['last_name'] = $user->cl_name;
                $s['email'] = $user->c_email;
                $s['password'] = $this->input->post('password');
                $s['phone'] = $user->c_mobile;
                $s['address'] = $user->c_address;
                $s['isLogin'] = true;

                $this->session->set_userdata($s);
            }

            return true;
        
        } else {
            $this->form_validation->set_message('verifylogin', 'Incorrect Login credentials');
            return false;
        }
    }

    public function logout()
    {

           $this->session->sess_destroy();
           redirect('login/login_customer');
    }
}