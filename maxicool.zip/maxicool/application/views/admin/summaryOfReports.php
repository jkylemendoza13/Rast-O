<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Summary of Reports</title>
</head>
<body>
	<?php 
		date_default_timezone_set('Asia/Hong_Kong');
        echo date('F j, Y - g:i a');
	?>
	<center>
			<h1>Summary of Reports</h1>
		<img src="./reports/Summary.png" width="1250px" height="530px">
	</center>
	<h4><b>Prepared by:</b> <?= $this->session->userdata('first_name'); ?> <?= $this->session->userdata('last_name'); ?></h4>
</body>
</html>