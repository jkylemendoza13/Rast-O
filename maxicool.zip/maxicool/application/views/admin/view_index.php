<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>MaxiCool</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url("assets/vendors/bootstrap/dist/css/bootstrap.min.css"); ?>" rel="stylesheet">
	<!--date picker -->
	<link href="<?php echo base_url("assets/datepicker3.css"); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url("assets/vendors/font-awesome/css/font-awesome.min.css"); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url("assets/vendors/nprogress/nprogress.css"); ?>" rel="stylesheet">
    <!-- sweet-alert --> 
    <link href="<?php echo base_url("assets/vendors/sweetalert/sweetalert.css"); ?>" rel="stylesheet">
    
    <!-- Custom Theme Style -->
    <link href="<?php echo base_url("assets/build/css/custom.min.css"); ?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/switch.css"); ?>" rel="stylesheet">


  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
             <a href="<?= base_url('admin/dashboard'); ?>" class="site_title">   <span>MaxiCool</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
                <div class="profile_pic">
                    <img src="<?= base_url('assets/images/pp.svg'); ?>" alt="..." class="img-circle profile_img">
                </div>
                <div class="profile_info">
                    <span>Welcome</span>
                    <h2><?= $this->session->userdata('first_name'); ?></h2>
                </div>
                <div class="clearfix"></div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <ul class="nav side-menu">
                  <li><a href="<?= base_url('admin/dashboard'); ?>"><i class="fa fa-home"></i> Dashboard </a></li>
                  <?php if($this->session->userdata('type') == "admin" ) : ?>
                  <li><a><i class="fa fa-edit"></i> Manage Users <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?= base_url('admin/employee/add'); ?>">Add new</a></li>
                      <li><a href="<?= base_url('admin/employee'); ?>">All Users</a></li>
                    </ul>
                  </li>
                  
                    <li>
                        <a><i class="fa fa-desktop"></i>Manufacturers &amp; Model <span class="fa fa-chevron-down"></span></a>

                        <ul class="nav child_menu">
                          <li><a href="<?php echo base_url() . 'admin/manufacturers';?>">Add Manufacturer</a></li>
                          <li><a href="<?php echo base_url() . 'admin/product_model';?>">Add Model</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                  <li><a><i class="fa fa-table"></i> Product <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?= base_url('admin/products'); ?>">All Products</a></li>
                      
                      
                    </ul>
                  </li>
                  <li><a href="<?= base_url('admin/orders/orderListAdminSide'); ?>">Orders</a></li>
                </ul>
              </div>
            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                                <a class="btn btn-success" target="_blank" href="dashboard/summaryofReports" style="margin-left: 13px;">Export Report</a>
              </div>
              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <?= $this->session->userdata('first_name'); ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    
                    <li><a href="<?php echo base_url() . 'admin/dashboard/logout'; ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->
<!-- page content -->
<div class="right_col" role="main" id="wholeBody">
    <div class="">

        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
				  <div class="row tile_count">
					<div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
						  <span class="count_top"><i class="glyphicon glyphicon-bed"></i> Total Products </span>
						  <div class="count"><?php echo count($products); ?></div>
					</div>
					<div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
						  <span class="count_top"><i class="glyphicon glyphicon-bed"></i> Total Employees </span>
						  <div class="count"><?php echo count($employees); ?></div>
					</div>
					<div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
						  <span class="count_top"><i class="glyphicon glyphicon-bed"></i> Total Customer </span>
						  <div class="count"><?php echo count($customers); ?></div>
					</div>
					<div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
					  	<span class="count_top"><i class="glyphicon glyphicon-bed"></i> Total Sold</span>
					  	<div class="count">
					  		<?php $price = 0; ?>
					  		<?php foreach($products as $products) : ?>
					  			<?php $price += ($products['price'] * $products['quantity']); ?>
					  		<?php endforeach; ?>
					  		<?= '₱' . $price ?>
					  	</div>
					</div>
				  </div>
            </div> <!-- /col --> 
        </div> <!-- /row -->

        <div class="row">
        	<div class="col-md-6 col-xs-12">
              	<div class="x_panel tile fixed_height_320">
                	<div class="x_title">
                  		<h2>Product Count in Manufacturers</h2>
	                  		<ul class="nav navbar-right panel_toolbox">
	                    	<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
	                        <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                  		</ul>
                  		<div class="clearfix"></div>
                	</div>
	                <div class="x_content">
						<?php $subtotal = 0; ?>
						<?php foreach ($manufacturers_group as $manufacturer) : ?>
							<?php $subtotal += $manufacturer['total']; ?>
						<?php endforeach; ?>

	                  	<?php foreach ($manufacturers_group as $manufacturer) : ?>
		                  	<div class="widget_summary">
			                    <div class="w_left w_25">
			                      <span><?= $manufacturer['manufacturer_name']; ?></span>
			                    </div>
			                    <div class="w_center w_55">
			                      	<div class="progress">
			                        	<div class="progress-bar bg-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo ($manufacturer['total'] / $subtotal) * 100;?>%">
			                        </div>
			                      </div>
			                    </div>
			                    <div class="w_right w_20">
			                      	<span><?= $manufacturer['total']; ?></span>
			                    </div>
			                    <div class="clearfix"></div>
		                  	</div>
	                  	<?php endforeach; ?>

	                </div> <!-- /content --> 
              	</div> <!-- /panel --> 
            </div> <!-- /col -->

            <div class="col-md-6 col-xs-12">
              	<div class="x_panel tile fixed_height_320">
                	<div class="x_title">
                  		<h2>Sold Product Count in Manufacturers</h2>
	                  		<ul class="nav navbar-right panel_toolbox">
	                    	<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
	                        <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                  		</ul>
                  		<div class="clearfix"></div>
                	</div>
	                <div class="x_content">
						<?php $subtotal = 0; ?>
						<?php foreach ($manufacturers_group_sold as $manufacturer) : ?>
							<?php $subtotal += $manufacturer['total']; ?>
						<?php endforeach; ?>

	                  	<?php foreach ($manufacturers_group_sold as $manufacturer) : ?>
		                  	<div class="widget_summary">
			                    <div class="w_left w_25">
			                      <span><?= $manufacturer['manufacturer_name']; ?></span>
			                    </div>
			                    <div class="w_center w_55">
			                      	<div class="progress">
			                        	<div class="progress-bar bg-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo ($manufacturer['total'] / $subtotal) * 100;?>%">
			                        </div>
			                      </div>
			                    </div>
			                    <div class="w_right w_20">
			                      	<span><?= $manufacturer['total']; ?></span>
			                    </div>
			                    <div class="clearfix"></div>
		                  	</div>
	                  	<?php endforeach; ?>

	                </div> <!-- /content --> 
              	</div> <!-- /panel --> 
            </div> <!-- /col --> 
        </div><!-- /row -->

        <div class="row">
        	<div class="col-md-6 col-xs-12">
        	  <img src="<?php echo base_url('assets/images/fixed.jpg'); ?>"> <!-- /panel --> 
        	</div>
        </div><!-- /row --> 
    </div>
</div> <!-- /.col-right --> 
<!-- /page content -->

<?php $this->load->view('admin/partials/admin_footer'); ?>
<script type="text/javascript">
	html2canvas(document.getElementById('wholeBody')).then(function(canvas) {
    // document.body.appendChild(canvas);

    $('#wholeBody').val(canvas.toDataURL("image/png"));

    var hid_img =  $('#wholeBody').val();

    $.ajax({
                        url: "<?= base_url('admin/dashboard/save_img') ?>",
                        type: "POST",
                        data: {
                            hid_img: hid_img,
                        }
                    });
    
   });
</script>