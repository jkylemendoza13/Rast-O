<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $type == 0 ? 'All' : ($type == 1 ? 'Pending' : 'Delivered')?> Reports</title>
	<link href="<?= base_url('assets/vendors/bootstrap/dist/css/bootstrap.min.css'); ?> " rel="stylesheet" type="text/css" media="all" />
</head>
<body>
	<?php 
		date_default_timezone_set('Asia/Hong_Kong');
        echo date('F j, Y - g:i a');
	?>
		<h3>MaxiCool</h3>
	<center>
			<h1><?php echo $type == 0 ? 'All' : ($type == 1 ? 'Pending' : 'Delivered')?> Reports</h1>
			<table class="table table-striped">
                            <tr>
                                <th>Customer Name</th>
                                <th>QR CODE</th>
                                <th>Delivery Address</th>
                                <th><?= $type == 2 ? 'Delivery Time' : 'Purchase Time'?></th>
                                <th>Status</th>
                            </tr>
                            <?php
                                foreach($orders as $order){?>
                            <tr>
                                <td><?php echo $order['name'];?></td>
                                <td><?php echo $order['qr_code'];?></td>
                                <td><?php echo $order['address'];?></td>
                                <?php if($type == 2){?>
                                <td><?php echo date("F j, Y - g:i a",strtotime($order["delivery_time"]));?></td>
                                <?php }
                                else{?>
                                <td><?php echo date("F j, Y - g:i a",strtotime($order["purchase_time"]));?></td>
                                <?php }?>
                                <td><?php echo $order['status'] == 0 ? 'Pending' : 'Delivered';?></td>
                            </tr>
                            <?php }?>
                        </table>
	</center>
	<h4><b>Prepared by:</b> <?= $this->session->userdata('first_name'); ?> <?= $this->session->userdata('last_name'); ?></h4>
</body>
</html>