<?php $this->load->view('admin/partials/admin_header.php'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Orders</h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <hr>
        <div class="row">
            <?php if($this->session->flashdata('msg')){?>
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="alert alert-warning" style="width: 20%;float: right">
                <strong>Success!</strong><?php echo $this->session->flashdata('msg');?>
            </div>
            <?php }?>
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Manage Orders </h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                        </ul>
 
                    
                    <div style="padding-left: 25%">

                        <div class="input-append date datepicker divDatePicker inline" id="datepicker" style="margin:0px;padding:0px;display:inline">
            <input type="text" class="datepicker input-small validation rightBorderNone otherTabs" id="fromDate" name="displayDate" placeholder="From Date" />
            <button class="btn leftBorderNone" type="button"><i class="glyphicon glyphicon-calendar"></i></button>
            </div>
        <div class="input-append date datepicker divDatePicker inline" id="datepicker" style="margin:0px;padding:0px;padding-left:4px;display:inline">
        <input type="text" placeholder="To Date" class="datepicker input-small validation rightBorderNone otherTabs" id="toDate" name="displayDate" />
        <button class="btn leftBorderNone" type="button"><i class="glyphicon glyphicon-calendar"></i></button>
        </div>
        <div class="input-append date datepicker divDatePicker inline" id="datepicker" style="margin:0px;padding:0px;display:inline">
            <a class="btn btn-success" target="_blank" href="<?php echo base_url() . 'admin/orders/report/'.$type; ?>">Export <?php echo ($type == 1 ? 'Pending' : ($type == 0 ? 'All' : 'Delivered'))?> Reports</a>
            </div>
        <div class="switch-toggle switch-3 switch-candy" style="margin-left: -310px;">
  <input id="on" name="state-d" type="radio" <?php echo ($type == 1 ? 'checked="checked"' : '');?> class="pendingSwitch"/>
  <label for="on" onclick="">PENDING</label>

  <input id="na" name="state-d" type="radio" <?php echo ($type == 0 ? 'checked="checked"' : '');?> class="allSwitch"/>
  <label for="na" onclick="">ALL</label>

  <input id="off" name="state-d" type="radio" <?php echo ($type == 2 ? 'checked="checked"' : '');?> class="deliveredSwitch"/>
  <label for="off" onclick="">DELIVERED</label>

  <a></a>
</div>
        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <table class="table table-striped">
                            <tr>
                                <th>Customer Name</th>
                                <th>QR CODE</th>
                                <th>Delivery Address</th>

                                <th><?= $type == 2 ? 'Delivery Time' : 'Purchase Time'?></th>
                                <th>Status</th>
                                <th>Receipt</th>
                                <th>Action</th>
                            </tr>
                            <?php
                                foreach($orders as $order){?>
                            <tr>
                                <td><?php echo $order['name'];?></td>
                                <td><?php echo $order['qr_code'];?></td>
                                <td><?php echo $order['address'];?></td>
                                <?php if($type == 2){?>
                                <td><?php echo date("F j, Y - g:i a",strtotime($order["delivery_time"]));?></td>
                                <?php }
                                else{?>
                                <td><?php echo date("F j, Y - g:i a",strtotime($order["purchase_time"]));?></td>
                                <?php }?>
                                <td><?php echo $order['driver_id'] == 0 ? '<button class="btn btn-success" data-qrcode="'.$order['qr_code'].'" data-toggle="modal" data-target="#myModal" id="add_to_driver">Add to Driver</button>' : ($order['status'] == 0 ? 'Pending' : 'Delivered');?></td>
                                <td><a class="btn btn-info" target="_blank" href="<?php echo base_url(); ?>admin/orders/receipt/<?php echo $order['id'];?>">View Receipt</a></td>
                                <td><a href="<?php echo base_url(); ?>admin/orders/removeOrder/<?php echo $order['id'];?>" class="btn btn-danger"onclick="confirm('Are you sure you want to remove this order?')" >Remove</a></td>
                            </tr>
                            <?php }?>
                        </table>
                        <!-- Modal -->
                        <div id="myModal" class="modal fade" role="dialog">
                          <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Choose Driver</h4>
                              </div>
                              <div class="modal-body">
                                <div class="container">
                                    <div class="col-lg-6 col-md-6">
                                                                      <form action="<?php echo base_url() ?>admin/orders/addToDriver" method="post">
                                <?php foreach($drivers as $driver){?>
                                    <div class="radio">
                                      <label><input type="radio" name="driver" value="<?php echo $driver['id'];?>" checked><?php echo $driver['name'];?></label>
                                    </div>
                                <?php }?>
                                <input type="hidden" name="qrCode" id="qr">
                                    <input type="submit" class="btn btn-primary" value="Add Order to Delivery">
                                </form>  
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                        <div class="table-responsive">
                                            <?php 
                                            date_default_timezone_set('Asia/Hong_Kong');
                                            echo date('Y-m-d H:i:s');

                                            ?>
                                            <table class="table table-bordered">
                                                <tr>
                                                    <th>Driver Name</th>
                                                    <th>Total Orders</th>
                                                    <th>Status</th>
                                                </tr>
                                                <?php foreach($driver_per_order as $order){?>
                                                    <tr>
                                                        <td><?php echo $order['name'];?></td>
                                                        <td><?php echo $order['total'];?></td>
                                                        <td><?php echo $order['total'] == 10 ? 'Not Available' : 'Available';?></td>
                                                    </tr>
                                                <?php }?>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              </div>
                            </div>

                          </div>
                        </div>
                    </div> <!-- /content --> 
                </div><!-- /x-panel --> 
            </div> <!-- /col --> 
        </div> <!-- /row --> 
    </div>
</div> <!-- /.col-right --> 
<!-- /page content -->

        <!-- footer content -->
        
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url('assets/vendors/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url("assets/vendors/bootstrap/dist/js/bootstrap.min.js"); ?> "></script>
    <!-- FastClick -->
    <script src="<?php echo base_url('assets/vendors/fastclick/lib/fastclick.js'); ?>"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url('assets/vendors/nprogress/nprogress.js'); ?>"></script>
    <!-- sweetalert --> 
    <script src="<?php echo base_url('assets/vendors/sweetalert/sweetalert.min.js'); ?>"></script>
    
    <!-- Chart.js -->
    <script src="<?php echo base_url('assets/vendors/Chart.js/dist/Chart.min.js'); ?>"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url('assets/build/js/custom.js'); ?>"> </script>
  </body>
</html>
<script type="text/javascript">
$('#add_to_driver').click(function(){
        $("#qr").val($(this).data("qrcode"));
    });
$('.pendingSwitch').click(function(){
    location.href = "pendingList";
});
$('.allSwitch').click(function(){
    location.href = "orderListAdminSide";
});
$('.deliveredSwitch').click(function(){
    location.href = "deliveredList";
});
</script>

