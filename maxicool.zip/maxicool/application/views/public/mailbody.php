<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="<?= base_url('assets/vendors/bootstrap/dist/css/bootstrap.min.css'); ?> " rel="stylesheet" type="text/css" media="all" />
</head>

<body>
    <h3>Welcome to MaxiCool!</h3>
    <h3>You are successfully registered.</h3>
    <h3>You can now order in our site.</h3>
    <h2><i><?php echo $name;?></i> this is your temporary password: <b><?php echo $temppassword;?></b>.</h2>
    <h4>You can changed it when you logged in.</h4>
</body>
</html>