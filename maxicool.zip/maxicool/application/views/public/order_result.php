<?php $this->load->view('public/partials/view_public_header.php'); ?>
<div class="container">
	<div class="col-md-6 col-md-offset-3">     
		<div class="row">
			<div id="logo" class="text-center">
			<h1>ORDER STATUS : <?= $lastLocation['status'] == 0 ? 'No Updates' : get_status($lastLocation['status']); ?></h1><p>Delivery Address : <?= $order['place']; ?></p>
			<?php if($order['driver_name'] != ''){?>
				<h3>Driver Name : <?= $order['driver_name']; ?></h3>
			<?php }?>
			<h4><?= $order['status'] == 0 ? '' : 'Thank You see you again in next Transaction'; ?></h4>
			</div>
			<?php echo form_open('admin/orders/showOrderDetails');?>
				<div class="form-group">
					<div class="input-group">
						<input id="1" class="form-control" type="text" name="search" placeholder="Search..." required/>
						<span class="input-group-btn">
						<button class="btn btn-success" type="submit">
						<i class="glyphicon glyphicon-search" aria-hidden="true"></i> Search
						</button>
						</span>
					</div>
				</div>
			<?php echo form_close();?>
		</div>            
	</div>
</div>
<div style="width:100%">
	<div class="maps" style="width: 50%;float: right;">
			<?php if(count($lastLocation) > 0){?>
              <iframe scrolling="false" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=<?= $lastLocation['latitude']; ?>,<?= $lastLocation['longitude']; ?>&key=AIzaSyBVPZIWcBs6SVr5uECLmrhe8c-9DD8dGe0" style="height:500px;width:100%;border:none;"></iframe>
             <?php }
             else{?>
             	<iframe scrolling="false" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=14.5963141,
120.9896037&key=AIzaSyBVPZIWcBs6SVr5uECLmrhe8c-9DD8dGe0" style="height:500px;width:100%;border:none;"></iframe>
             <?php }?>
    </div>
	<div style="width: 50%;background-color: white;height: 500px;float: left;">
		<?php 
		if($coordinates){
			if($coordinates || $firstLocation['status'] == 1){?>
		<table class="table table-bordered table-hover">
			<caption>Stop Overs</caption>
  <thead>
    <tr>
      <th scope="col">Last Known Location</th>
      <th scope="col">Status</th>
      <th scope="col">Interval</th>
    </tr>
  </thead>
  <tbody>
  	<?php if($lastLocation['status'] == 5){?>
  	<tr>
  		<td><?= getAddress($lastLocation['latitude'],$lastLocation['longitude']); ?></td>
  		<td><?= get_status($lastLocation['status']); ?></td>
      	<td><?= get_time_ago($lastLocation['report_time']); ?></td>
  	</tr>
  	<?php }?>

  	<?php
  		$index=0; 
  		foreach($coordinates as $coor) : ?>
  		<?php if($lastLocation['status'] == 5){?>
  			<?php if($index != 0){?>
  			  	<tr>
			      <td><?= getAddress($coor['latitude'],$coor['longitude']); ?></td>
			      <td><?= get_status($coor['status']); ?></td>
			      <td><?= get_time_ago($coor['report_time']); ?></td>
			    </tr>
			<?php }?>
  		<?php }
  			else{?>
  				<tr>
			      <td><?= getAddress($coor['latitude'],$coor['longitude']); ?></td>
			      <td><?= get_status($coor['status']); ?></td>
			      <td><?= get_time_ago($coor['report_time']); ?></td>
			    </tr>
  		<?php }
  		$index++;
  		?>
   <?php endforeach; ?>
   	  <tr>
  		<td><?= getAddress($firstLocation['latitude'],$firstLocation['longitude']); ?></td>
  		<td><?= get_status($firstLocation['status']); ?></td>
      	<td><?= get_time_ago($firstLocation['report_time']); ?></td>
  	</tr>
  </tbody>
</table>
<?php }
}
else if(isset($firstLocation['status'])){?>
	<table class="table table-bordered table-hover">
			<caption>Stop Overs</caption>
  <thead>
    <tr>
      <th scope="col">Last Known Location</th>
      <th scope="col">Status</th>
      <th scope="col">Interval</th>
    </tr>
  </thead>
  <tbody>
  	<tr>
  		<td><?= getAddress($firstLocation['latitude'],$firstLocation['longitude']); ?></td>
  		<td><?= get_status($firstLocation['status']); ?></td>
      	<td><?= get_time_ago($firstLocation['report_time']); ?></td>
  	</tr>
  </tbody>
</table>
<?php }
else{?>
	<h1><center>No Stop Overs yet!</center></h1>
<?php }?>
	</div>
</div>
<?php $this->load->view('public/partials/view_public_footer.php'); ?>