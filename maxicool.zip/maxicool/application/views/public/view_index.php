<?php $this->load->view('public/partials/view_public_header.php'); ?>
<div class="banner">
	<div class="container">
		<script src="<?= base_url('assets/js/responsiveslides.min.js'); ?>"></script>
		<script>
		$(function () {
		$("#slider").responsiveSlides({
			auto: true,
			nav: true,
			speed: 500,
		namespace: "callbacks",
		pager: true,
		});
		});
		</script>
		<div  id="top" class="callbacks_container">
			<ul class="rslides" id="slider">
				<li>
					
					<div class="banner-text">
						<h3>MaxiCool   </h3>
						<p>As one of the best in providing customer service, Maxicool Company help companies leverage 	customer’s knowledge to achieve greater customer loyalty, reduce costs, drive innovation and 	increase revenue.</p>
						
					</div>
					
				</li>

              <li>
					
					<div class="banner-text">
						<h3>The MaxiCool   </h3>
						<p>Maxicool shall be one of the recognized leader in providing innovative industrial refrigeration equipment and services, customer care, employee care, and other transaction services to the market we serve.</p>
						
					</div>
					
				</li>



				<li>
					
					<div class="banner-text">
						<h3>For our Clients:</h3>
						<p>We will endeavor to provide our customers leading-edge products and services that offer an 	optimum value and create competitive edge.</p>
						
					</div>
					
				</li>
				<li>
					<div class="banner-text">
						<h3>Why Rast'O?</h3>
						<p>The word Rast'O came from combination of two latin words which is Rastreo and Orden. Rastreo means tracking or is to track. And Orden means order. We came up to this idea to make na name for this web site.</p>
						
					</div>
					
				</li>
			</ul>
		</div>
	</div>
</div>
<!--content-->
<div class="container">
	<div class="cont">
		<div class="content">
			<div class="content-top-bottom">
				<h2>Featured PRODUCTS</h2>
				<?php foreach($featured as $feature) : ?>
					<div class="col-md-4 men">
						<a href="<?php echo base_url('pages/show') . '/' . $feature['product_id']; ?> " class="b-link-stripe b-animate-go  thickbox">
							<img style="height: 260px;" class="img-responsive" src="<?= base_url('uploads'); ?>/<?php echo $feature['image']; ?>" alt="">
							<div class="b-wrapper">
								<h3 class="b-animate b-from-top top-in   b-delay03 ">
								<span><?php echo $feature['model_name']; ?></span>
								</h3>
							</div>
						</a>
					</div>
				<?php endforeach; ?>
				<div class="clearfix"> </div>
			</div>
			<div class="content-top">
				<h1>NEW PRODUCTS</h1>
				
				<div class="grid-in">
					{products}
						<div class="col-md-3 grid-top simpleCart_shelfItem">
							<a href="<?= base_url(); ?>pages/show/{product_id}" class="b-link-stripe b-animate-go  thickbox">
							<img class="img-responsive" src="<?= base_url('uploads/'); ?>/{image}" alt="">
								<div class="b-wrapper">
									<h3 class="b-animate b-from-left    b-delay03 ">
									<span>{model_name}</span>
									
									</h3>
								</div>
							</a>
							
							<p><a href="single.html">{model_name}</a></p>
						</div>
					{/products}
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		
	</div>
	
</div>
<?php $this->load->view('public/partials/view_public_footer.php'); ?>