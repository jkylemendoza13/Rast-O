<!DOCTYPE html>
<html>
<head>
<title>Sign Up</title>
<link href="<?= base_url('assets/vendors/bootstrap/dist/css/bootstrap.min.css'); ?> " rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="<?= base_url('assets/css/style.css'); ?>" rel="stylesheet" type="text/css" media="all" />   
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'><!--//fonts-->
<!-- start menu -->
<link href="<?= base_url('assets/css/memenu.css'); ?>" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="<?php echo base_url('assets/build/css/login.css'); ?>">
<script>$(document).ready(function(){$(".memenu").memenu();});</script>
</head>
<body>
<!--header-->
<div class="header">
    <div class="header-top">
        <div class="container">
            <div class="social">
                <ul>
                    <li><a href="#"><i class="facebok"> </i></a></li>
                    <li><a href="#"><i class="twiter"> </i></a></li>
                    <li><a href="#"><i class="inst"> </i></a></li>
                    <li><a href="#"><i class="goog"> </i></a></li>
                        <div class="clearfix"></div>    
                </ul>
            </div>
        </div>
        </div>
    </div>
    <div class="loginPage" style="top: 33%">   
        <form action="<?php echo base_url() ?>login/signUpProcess" method="post">
                            <fieldset>
                                <?php if($this->session->flashdata('email_error')){?>
                <div class="alert alert-danger">
                <strong>Error!</strong> <?php echo $this->session->flashdata('email_error');?>
            </div>
        <?php }?>
                                <div class="form-group">
                                    Email : <input class="form-control" placeholder="E-mail" name="u_email" id="username" type="text" required="required" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}$" title="Enter Valid Email" value="<?= $this->session->userdata('u_email'); ?>">
                                </div>
                                <div class="form-group">
                                    First Name : <input class="form-control" placeholder="First Name" name="f_name" required="required" type="text" value="<?= $this->session->userdata('f_name'); ?>">
                                </div>
                                <div class="form-group">
                                    Last Name : <input class="form-control" required="required" placeholder="Last Name" name="l_name" type="text" value="<?= $this->session->userdata('l_name'); ?>">
                                </div>
                                <div class="form-group">
                                    Mobile : <input class="form-control" placeholder="Mobile" name="u_mobile" type="text" name="mobile" pattern="^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[9]\d{9}$" title="Enter Valid mobile number ex.9081234567" required type="text" value="<?= $this->session->userdata('phone'); ?>">
                                </div>
                                <div class="form-group">
                                    Address: <textarea rows="3" cols="10" class="form-control" required="required" name="u_address"><?= $this->session->userdata('address'); ?></textarea>
                                </div>
                                <input type="submit" name="buttonSubmit" value="Update Changes" class="btn btn-primary" style="margin-bottom: 10px;color: white"/>
                            </fieldset>
                        </form>
    </div>
</body>
</html>