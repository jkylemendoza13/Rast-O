<?php $this->load->view('public/partials/view_public_header.php'); ?>
<div class="container">
	<table class="table table-bordered table-hover" align="center">
			<caption>List of Orders</caption>
  <thead>
    <tr>
      <th scope="col">QR Code</th>
      <th scope="col">View Details</th>
      <th scope="col">Status</th>
      <th scope="col">Purchase Time</th>
      <th scope="col">Delivered Time</th>
    </tr>
  </thead>
  <tbody>
  	<?php foreach($orders as $order) : ?>
    <tr>
      <td><?php echo $order["qr_code"]; ?></td>
      <td>
      	<form name="myform" id="myform" action="<?php echo base_url() ?>admin/orders/viewOrderDetails" method="post">
		<input type="hidden" name="id" id="id" value="<?php echo $order["id"] ?>" />
		<input type="submit" class="btn btn-success btn-sm" value="See details" />
		</form>
      <td><?php echo $order["status"] == 0 ? 'Pending' : 'Delivered'; ?></td>
      <td><?php echo date("F j, Y - g:i a",strtotime($order["purchase_time"]));?></td>
      <td><?php echo $order["status"] == 0 ? '' : date("F j, Y - g:i a",strtotime($order["delivery_time"]));?></td>
    </tr>
   <?php endforeach; ?>

  </tbody>
</table>
</div>
<?php $this->load->view('public/partials/view_public_footer.php'); ?>