<?php $this->load->view('public/partials/view_public_header.php'); ?>
<div class="container">
	<table class="table table-bordered table-hover">
			<caption>List of Product Orders</caption>
  <thead>
          <tr>
            <th width="40%">Name</th>
            <th width="15%">Quantity</th>
            <th width="15%">Price</th>
            <th width="15%">Total</th>
          </tr>
  </thead>
  <?php $count = 0;
    $total = 0;
    foreach($order_details as $details){
      $count++;
      $total += ($details['price']*$details['quantity']) ;?>
        <tr>
          <td><?php echo $details['product'];?></td>
          <td><?php echo $details['quantity'];?></td>
          <td><?php echo number_format($details['price'],2);?></td>
          <td><?php echo number_format(($details['price']*$details['quantity']),2);?></td>
        </tr>
    <?php }?>
        <tr>
          <td colspan="3" align="right">Total</td>
          <td><?php echo number_format($total,2);?></td>
        </tr>
      </table>
</table>
</div>
<?php $this->load->view('public/partials/view_public_footer.php'); ?>
