<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link href="<?= base_url('assets/vendors/bootstrap/dist/css/bootstrap.min.css'); ?> " rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="<?= base_url('assets/css/style.css'); ?>" rel="stylesheet" type="text/css" media="all" />   
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'><!--//fonts-->
<!-- start menu -->
<link href="<?= base_url('assets/css/memenu.css'); ?>" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="<?php echo base_url('assets/build/css/login.css'); ?>">
<script>$(document).ready(function(){$(".memenu").memenu();});</script>
</head>
<body>
<!--header-->
<div class="header">
    <div class="header-top">
        <div class="container">
            <div class="social">
                <ul>
                    <li><a href="#"><i class="facebok"> </i></a></li>
                    <li><a href="#"><i class="twiter"> </i></a></li>
                    <li><a href="#"><i class="inst"> </i></a></li>
                    <li><a href="#"><i class="goog"> </i></a></li>
                        <div class="clearfix"></div>    
                </ul>
            </div>
        </div>
        </div>
    </div>
    <div class="loginPage">    
        <header>
            <h2>Login</h2>
        </header>
        <?php echo validation_errors(); ?>
        <?php if(isset($message)){?>
        <div class="alert alert-success alert-dismissible">
          <strong>Success!</strong><?php echo $message;?>
        </div>
        <?php }?>
        <?php echo form_open('login/checkloginCustomer'); ?>
            <input placeholder="Email" type="email" name="email">
            <input placeholder="Password" type="password" name="password">
            <section class="links">
                <button class="button"><span>LOGIN</span></button>
                <center><a href="<?php echo base_url(); ?>login/signUp" class="btn btn-success"><span>Sign Up</span></a></center>
                <br><br>
            </section>
        </form>
    </div>