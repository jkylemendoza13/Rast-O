<?php $this->load->view('public/partials/view_public_header.php'); ?>
<div class="container">
	<div class="col-md-6 col-md-offset-3">     
		<div class="row">
			<div id="logo" class="text-center">
			<h1>Search</h1><p>Order Number</p>
			</div>
			<?php echo form_open('admin/orders/showOrderDetails');?>
				<div class="form-group">
					<div class="input-group">
						<input id="1" class="form-control" type="text" name="search" placeholder="Search..." required/>
						<span class="input-group-btn">
						<button class="btn btn-success" type="submit">
						<i class="glyphicon glyphicon-search" aria-hidden="true"></i> Search
						</button>
						</span>
					</div>
				</div>
			<?php echo form_close();?>
		</div>            
	</div>
</div>
<?php $this->load->view('public/partials/view_public_footer.php'); ?>