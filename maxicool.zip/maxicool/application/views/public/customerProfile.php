<?php $this->load->view('public/partials/view_public_header.php'); ?>
<div class="container">
	<div class="col-lg-6 col-md-6">
    <div id="cart_details">
        <?php if($this->session->flashdata('msg')){?>
        <div class="alert alert-success alert-dismissible">
          <strong>Success!</strong><?php echo $this->session->flashdata('msg');?>
        </div>
        <?php }?>
        <h3 align="center">Profile Information</h3>
        <form action="<?php echo base_url() ?>customer/updateProfile" method="post">
                            <fieldset>
                                <div class="form-group">
                                    Email : <input class="form-control" placeholder="E-mail" name="u_email" id="username" type="email" required="required" value="<?= $this->session->userdata('email'); ?>">
                                </div>
                                <div class="form-group">
                                    First Name : <input class="form-control" placeholder="First Name" name="f_name" required="required" type="text" value="<?= $this->session->userdata('first_name'); ?>">
                                </div>
                                <div class="form-group">
                                    Last Name : <input class="form-control" required="required" placeholder="Last Name" name="l_name" type="text" value="<?= $this->session->userdata('last_name'); ?>">
                                </div>
                                <div class="form-group">
                                    Mobile : <input class="form-control" required="required" placeholder="Mobile" name="u_mobile" type="text" value="<?= $this->session->userdata('phone'); ?>">
                                </div>
                                <div class="form-group">
                                    Address: <textarea rows="3" cols="10" class="form-control" required="required" name="u_address"><?= $this->session->userdata('address'); ?></textarea>
                                </div>
                                <input type="submit" name="buttonSubmit" value="Update Changes" class="btn btn-success" style="margin-bottom: 10px"/>
                            </fieldset>
                        </form>
      </div>
  </div>

  <div class="col-lg-6 col-md-6">
      <div id="cart_details">
        <?php if($this->session->flashdata('msg_password')){?>
        <div class="alert alert-success alert-dismissible">
          <strong>Success!</strong><?php echo $this->session->flashdata('msg_password');?>
        </div>
        <?php }?>
        <h3 align="center">Change Password</h3>
        <form method="post" action="<?php echo base_url() ?>customer/userChangePassword" id="formChangePassword" onclick="validatePassword()">
                            <fieldset>
                                <div class="form-group">
                                    Old Password : <input class="form-control" required="required" placeholder="Old Password" id="old_password" type="password">
                                    <input type="hidden" id="old_password_db" value="<?php echo $this->session->userdata('password');?>">
                                </div>
                                <div class="form-group">
                                    New Password : <input class="form-control" required="required" placeholder="New Password" id="new_password" name="new_password" type="password">
                                </div>
                                <div class="form-group">
                                    Confirm Password : <input class="form-control" required="required" placeholder="Confirm Password" id="confirm_password" type="password">
                                </div>
                                <input type="submit" name="buttonSubmit" value="Update Changes" class="btn btn-info" style="margin-bottom: 10px"/>
                            </fieldset>
                        </form>
      </div>
    </div>
</div>
<div class="footer w3layouts">
  <div class="container">
    <div class="footer-top-at w3">
      
      <div class="col-md-3 amet-sed w3l">
        <h4>MORE INFO</h4>
        <ul class="nav-bottom">
          <li><a href="#">How to order</a></li>
          <li><a href="#">FAQ</a></li>
          <li><a href="contact.html">Location</a></li>
          <li><a href="#">Shipping</a></li>
          <li><a href="#">Membership</a></li>
        </ul>
      </div>
      <div class="col-md-3 amet-sed w3ls">
        <h4>CATEGORIES</h4>
        <ul class="nav-bottom">
          <li><a href="#">Valve</a></li>
          <li><a href="#">Auto Purger</a></li>
          <li><a href="#">Gas Sensor</a></li>
          <li><a href="#">Temperature</a></li>
          <li><a href="#">At iba pa</a></li>
        </ul>
        
      </div>

      <div class="col-md-3 amet-sed agileits-w3layouts">
        <h4>For more Info</h4>
        <p>Contact us: inqueriesmaxicool@gmail.com</p>
        
      </div>

      <div class="col-md-3 amet-sed agileits-w3layouts">
        <h4>MaxiCool Office</h4>
        <p>4/F Maxicool Building, B51 L8 Pinagsama Village</p>
        <p>Western Bicutan, Taguig City, Metro Manila 1631</p>
        <p>Office :  +880 134 995 0792</p>
      </div>
      <div class="clearfix"> </div>
    </div>
  </div>
  <div class="footer-class w3-agile">
    <p>© 2018. All Rights Reserved</p>
  </div>
</div>
</body>
</html>
<script type="text/javascript">
    var password = document.getElementById("new_password")
    , confirm_password = document.getElementById("confirm_password");
    var old_password = document.getElementById("old_password")
    , old_password_db = document.getElementById("old_password_db");
    var checkValidateConfirm = false,checkValidateOld = false;

function validatePassword(){
  console.log('clicked');
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
    checkValidateConfirm = false;
  } else {
    confirm_password.setCustomValidity('');
    checkValidateConfirm = true;
  }
  if(old_password.value != old_password_db.value ) {
    old_password.setCustomValidity("Old Password Don't Match the current");
    checkValidateConfirm = false;
  } else {
    old_password.setCustomValidity('');
    checkValidateOld = true;
  }
  if(checkValidateConfirm == true && checkValidateOld == true){
    document.getElementById("formChangePassword").submit();
  }
}
</script>