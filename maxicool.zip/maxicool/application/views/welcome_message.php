<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Receipt</title>
	<link href="<?= base_url('assets/vendors/bootstrap/dist/css/bootstrap.min.css'); ?> " rel="stylesheet" type="text/css" media="all" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="col-lg-6 col-md-6">
			<img src="./assets/images/maxicool.jpg" width="40%" height="200px">
			<img src="./qrcodes/<?php echo $qrCode;?>.png" width="30%" height="30%" style="float: right;">
		</div>
		<h4>MaxiCool Industries & Corporation</h4>
		<h4>4/F MaxiCool Building,B51 L8 Pinagsama Village</h4>
		<h4>Western Bicutan, Taguig City, Metro Manila 1631</h4>
		<h4><b>TIN:05473648</h4>
		<h4><b>Bill To:</b> <?php echo $user_details['name'];?></h4>
		<h4><b>Purchase Time :</b> <?php echo date("F j, Y - g:i a",strtotime($user_details['purchase_time']));?></h4></br></br></br></br>
		<h4 style="float: right;"><b>Shipping Address:</b> <?php echo $user_details['address'];?></h4>
		<div class="table-responsive" style="margin-top: 60px">
			<h3 align="center">Product List</h3>
			<table class="table table-bordered">
					<tr>
						<th width="40%">Product</th>
						<th width="15%">Quantity</th>
						<th width="15%">Price</th>
						<th width="15%">Total</th>
					</tr>
		<?php
		$count = 0;
		$total = 0;
		foreach($order_details as $orders){
			$count++;
			$total += ($orders['price'] * $orders['quantity']) ;?>
				<tr>
					<td><?php echo $orders['product'];?></td>
					<td><?php echo $orders['quantity'];?></td>
					<td><?php echo number_format($orders['price'],2);?></td>
					<td><?php echo number_format($orders['price'] * $orders['quantity'],2);?></td>
				</tr>
		<?php }?>
				<tr>
					<td colspan="3" align="right">Total</td>
					<td><?php echo number_format($total,2);?></td>
				</tr>
			</table>
		</div>
		<h4><b>Driver:</b> <?php echo $driver_details['driver_name'];?></h4>
	</div>
</body>
</html>