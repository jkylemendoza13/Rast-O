<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class model_product extends CI_Model {

	public function insert($featured,$image,$manufacturer_id,$model_id,$category,$buying_price,$add_date,$status,$product_name,$user_id)
	{
		$data = array(
			'featured' => $featured,
			'image' => $image,
			'manufacturer_id' => $manufacturer_id,
			'model_id' => $model_id,
			'category' => $category,
			'buying_price' => $buying_price,
			
			'add_date' => $add_date,
			'status' => $status,
			'product_name' => $product_name,
			
			'user_id' => $user_id,
			
			
        );

		$this->db->insert('products', $data); 
	}

	public function getAll()
	{
		// $result = $this->db->get('products');
		$this->db->select('*');
        $this->db->from('products');
        $this->db->join('manufacturers', 'manufacturers.id = products.manufacturer_id','inner');
        $this->db->join('models', 'models.id = products.model_id', 'inner');
        $result = $this->db->get();
		return $result->result_array();
	}

	public function getAllByManufacturer()
	{
		// $result = $this->db->get('products');
		$this->db->select('*, COUNT(manufacturer_id) as total');
        $this->db->from('products');
        $this->db->join('manufacturers', 'manufacturers.id = products.manufacturer_id','inner');
        // $this->db->join('models', 'models.id = products.model_id', 'inner');
        $this->db->group_by('manufacturer_id');
        $this->db->order_by('total', 'desc'); 
        $result = $this->db->get();
		return $result->result_array();
	}

	public function getAllByManufacturerSold()
	{
		// $result = $this->db->get('products');
		$this->db->select('*, COUNT(manufacturer_id) as total');
        $this->db->from('order_details');
        $this->db->join('manufacturers', 'manufacturers.id = order_details.manufacturer_id','inner');
        // $this->db->join('models', 'models.id = products.model_id', 'inner');
        $this->db->group_by('manufacturer_id');
        $this->db->order_by('total', 'desc'); 
        $result = $this->db->get();
		return $result->result_array();
	}


	public function getLatest()
	{
		// $result = $this->db->get('products');
		$this->db->select('*');
        $this->db->from('products');
        $this->db->join('manufacturers', 'manufacturers.id = products.manufacturer_id','inner');
        $this->db->join('models', 'models.id = products.model_id', 'inner');
        $this->db->order_by("product_id", "desc");
        $this->db->limit(4);
        $result = $this->db->get();
		return $result->result_array();
	}

	public function getFeatured()
	{
		//$result = $this->db->get('products');
		$this->db->select('*');
        $this->db->from('products');
        $this->db->join('manufacturers', 'manufacturers.id = products.manufacturer_id','inner');
        $this->db->join('models', 'models.id = products.model_id', 'inner');
        $this->db->where("featured", 1);
        $this->db->order_by("product_id", "desc");
        $this->db->limit(4);
        $result = $this->db->get();
		return $result->result_array();
	}

	public function getById($product_id)
	{
		// $result = $this->db->get('products');
		$this->db->select('*');
        $this->db->from('products');
        $this->db->join('manufacturers', 'manufacturers.id = products.manufacturer_id','inner');
        $this->db->join('models', 'models.id = products.model_id', 'inner');
        $this->db->where('product_id', $product_id);
        $this->db->limit(1);
        $result = $this->db->get();
		return $result->result_array();
	}
        
    public function customerList()
	{
		
		$this->db->select('*');
        $this->db->from('customer');
        $result = $this->db->get();
		return $result->result_array();
	}
        
	public function get($p_id)
	{
		$this->db->where('product_id', $v_id);
		$result = $this->db->get('products');
		return $result->row_array();
	}
    

    public function sell($p_id,$cf_name,$cl_name,$c_email,$s_price,$c_mobile,$w_start,$w_end,$payment_type,$c_pass)
	{
				
		$data = array(
               'status' => 'sold',
               'selling_price' => $s_price,
               'sold_date' => $w_start
            );
		$this->db->where('product_id', $p_id);
		$this->db->update('products', $data); 
		
		$datac = array(
               'product_id' => $p_id,
               'cf_name' => $cf_name,
               'cl_name' => $cl_name,
               'c_email' => $c_email,
               'c_mobile' => $c_mobile,
               'w_start' => $w_start,
               'w_end' => $w_end,
               'payment_type' => $payment_type,
               'c_pass' => $c_pass
            );
		$this->db->insert('customer', $datac);
	}

	public function delete($id)
	{
		$this->db->where('product_id', $id);
		$this->db->delete('products');
	}
        
    public function deletecustomer($c_id, $p_id)
	{
		$this->db->where('c_id', $c_id);
		$this->db->delete('customer'); 
                
        $data = array(
       'status' => 'available',
       'selling_price' => NULL,
       'sold_date' => NULL
        );
		$this->db->where('product_id', $p_id);
		$this->db->update('products', $data);
	}

	public function get_product_by_month(){
        $this->db->select('*, MONTH(add_date) as month,  YEAR(add_date) as year, SUM(buying_price) as b_price, SUM(selling_price) as s_price');
        $this->db->from('products');
        $this->db->group_by('month');
        $query = $this->db->get();
        return $query->result();
    }
}