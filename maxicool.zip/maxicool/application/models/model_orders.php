<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class model_orders extends CI_Model {

   public function getSoldOrders(){
    $this->db->select('price,quantity');
    $this->db->from('order_details');
    $query = $this->db->get();
    return $query->result_array(); 
   }

   public function getAllORDERS(){
    $this->db->select('orders.id as id,CONCAT((customer.cf_name),(" "),(customer.cl_name)) as name,orders.qr_code as qr_code,orders.place as address,orders.status as status,orders.driver_id as driver_id,orders.purchase_time as purchase_time,orders.delivery_time as delivery_time',FALSE);
    $this->db->from('orders');
    $this->db->join('customer','customer.c_id = orders.customer_id');
    $query = $this->db->get();
     return $query->result_array();
   }

   public function getPending(){
    $this->db->select('orders.id as id,CONCAT((customer.cf_name),(" "),(customer.cl_name)) as name,orders.qr_code as qr_code,orders.place as address,orders.status as status,orders.driver_id as driver_id,orders.purchase_time as purchase_time',FALSE);
    $this->db->from('orders');
    $this->db->join('customer','customer.c_id = orders.customer_id');
    $this->db->where('orders.status',0);
    $query = $this->db->get();
     return $query->result_array();
   }

   public function getDelivered(){
    $this->db->select('orders.id as id,CONCAT((customer.cf_name),(" "),(customer.cl_name)) as name,orders.qr_code as qr_code,orders.place as address,orders.status as status,orders.driver_id as driver_id,orders.purchase_time as purchase_time,orders.delivery_time as delivery_time',FALSE);
    $this->db->from('orders');
    $this->db->join('customer','customer.c_id = orders.customer_id');
    $this->db->where('orders.status',1);
    $query = $this->db->get();
     return $query->result_array();
   }

   public function getSpecifiOrderDetails($orderID){
    $this->db->select('orders.id as id,CONCAT((customer.cf_name),(" "),(customer.cl_name)) as name,orders.place as address,orders.purchase_time',FALSE);
    $this->db->from('orders');
    $this->db->join('customer','customer.c_id = orders.customer_id');
    $this->db->where('id',$orderID);
    $query = $this->db->get();
    return $query->row_array();
   }

   public function getOrderDriver($orderID){
    $this->db->select('orders.id as id,CONCAT((users.first_name),(" "),(users.last_name)) as driver_name',FALSE);
    $this->db->from('orders');
    $this->db->join('users','users.id = orders.driver_id');
    $this->db->where('orders.id',$orderID);
    $query = $this->db->get();
    return $query->row_array();
   }

   public function addToDriver(){
    $this->db->set('driver_id',$this->input->post('driver'));
    $this->db->where('qr_code', $this->input->post('qrCode'));
    $this->db->update('orders');
     } 

  public function removeOrder($id){
    $this->db->where('id', $id);
    $this->db->delete('orders');
    $this->db->where('order_id', $id);
    $this->db->delete('order_details');
  }

	 public function searchORDER_number($qrCode){
    $this->db->where('qr_code', $qrCode);
		$query = $this->db->get('orders');
    $q = $query->row_array();
    // var_dump($q);
    $this->db->select('orders.id as id,CONCAT((users.first_name),(" "),(users.last_name)) as driver_name,orders.qr_code as qr_code,orders.place as place,orders.status as status',FALSE);
    $this->db->from('orders');
    $this->db->join('users','orders.driver_id = users.id','left');
    $this->db->where('qr_code', $qrCode);
    $query2 = $this->db->get();
    return $query2->row_array();
	 }

   public function getQRCODE($orderNumber){
    $this->db->where('id', $orderNumber);
    return $this->db->get('orders')->row()->qr_code;
   }

    public function getORDERS(){
      $this->db->where('customer_id',$this->session->userdata('id'));
      $query = $this->db->get("orders");
      return $query->result_array();
    }

    public function getOrderDetails($orderID){
      $this->db->where('order_id',$orderID);
      $query = $this->db->get("order_details");
      return $query->result_array();
    }

	 public function order_products(){
   		$query = $this->db->get("products");
   		return $query->result();
    }

    public function get_temporary_orders(){
      $this->db->where('customer_id',$this->session->userdata('id'));
   		$query = $this->db->get("temporary_orders");
   		return $query->result();
    }

    public function clearCart(){
    	$this->db->where('customer_id', $this->session->userdata('id'));
      $this->db->delete('temporary_orders');
    }

    public function removeTemporaryOrder($id){
    	$this->db->where('id', $id);
    	$this->db->delete('temporary_orders');
    }

    public function add_product_order($productID,$productName,$productPrice,$productQuantity,$manufacturerID){

      $this->db->where('product_id', $productID);
      $this->db->where('customer_id', $this->session->userdata('id'));
      $query = $this->db->get('temporary_orders');
        if($query->num_rows()==1) {
          $quantityDB=0;
          foreach ($query->result_array() as $row)
          {
            $quantityDB = $row['product_quantity'];
          }
          $this->db->set('product_quantity',(int)$quantityDB + (int)$productQuantity);
          $this->db->where('product_id', $productID);
          $this->db->where('customer_id', $this->session->userdata('id'));
          $this->db->update('temporary_orders');
        }
        else{
          $data = array(
               'customer_id' => $this->session->userdata('id'),
               'product_id' => $productID,
               'product_name' => $productName,
               'product_price' => $productPrice,
               'product_quantity' => $productQuantity,
               'manufacturer_id' => $manufacturerID
            );
          $this->db->insert('temporary_orders', $data);    
        }
   		
    }

    public function addOrder(){
      date_default_timezone_set('Asia/Hong_Kong');

      $exist = 1;
      $QRCODE='';
      while($exist == 1){
        $QRCODE = $this->get_rand_alphanumeric(8);
        $this->db->where('qr_code', $QRCODE);
        $result = $this->db->get('orders');
        if($result->num_rows()==1) {
          $exist = 1;
        }
        else{
          $exist = 0;
        }
      }
      $data = array(
               'customer_id' => $this->session->userdata('id'),
               'customer_phone_number' => $this->session->userdata('phone'),
               'qr_code' => $QRCODE,
               'place' => $this->session->userdata('address'),
               'purchase_time' => date('Y-m-d H:i:s')
            );
      $this->db->insert('orders', $data);
      $ORDER_ID = $this->db->insert_id();

      $this->db->where('customer_id', $this->session->userdata('id'));
      $query = $this->db->get('temporary_orders');
      foreach ($query->result_array() as $row)
          {
            $quantityDB = $row['product_quantity'];
            $data = array(
                     'order_id' => $ORDER_ID,
                     'product' => $row['product_name'],
                     'price' => $row['product_price'],
                     'quantity' => $row['product_quantity'],
                     'manufacturer_id' => $row['manufacturer_id']
                  );
            $this->db->insert('order_details', $data);
          }
      $this->clearCart();
      return $QRCODE;
    }

	public function getCoordinates($orderID)
	{
        $this->db->where('order_id', $orderID);
        $this->db->where('status >', 1);
        $this->db->order_by('id', 'DESC');
		$result = $this->db->get('coordinates');
		return $result->result_array();
	}

	public function getLastKnownLocation($orderID)
	{
      $this->db->where('order_id', $orderID);
      $this->db->where('status', 5);
      $this->db->order_by('id', 'DESC');
  		$result = $this->db->get('coordinates');
      if($result->num_rows()==1) {
        return $result->row_array();
      }
      else{
        $this->db->where('order_id', $orderID);
        $this->db->order_by('id', 'DESC');
        $result = $this->db->get('coordinates');
        return $result->row_array();
      }
		
	}
  public function getFirstLocation($orderID)
  {
        $this->db->where('order_id', $orderID);
        $this->db->where('status', 1);
        $result = $this->db->get('coordinates');
        return $result->row_array();
  }

  //function for generating QRCODE
  public function get_rand_alphanumeric($length) {
    if ($length>0) {
        $rand_id="";
        for ($i=1; $i<=$length; $i++) {
            mt_srand((double)microtime() * 1000000);
            $num = mt_rand(1,36);
            $rand_id .= $this->assign_rand_value($num);
        }
    }
    return $rand_id;
  }

  public function assign_rand_value($num) {

    // accepts 1 - 36
      switch($num) {
          case "1"  : $rand_value = "A"; break;
          case "2"  : $rand_value = "B"; break;
          case "3"  : $rand_value = "C"; break;
          case "4"  : $rand_value = "D"; break;
          case "5"  : $rand_value = "E"; break;
          case "6"  : $rand_value = "F"; break;
          case "7"  : $rand_value = "G"; break;
          case "8"  : $rand_value = "H"; break;
          case "9"  : $rand_value = "I"; break;
          case "10" : $rand_value = "J"; break;
          case "11" : $rand_value = "K"; break;
          case "12" : $rand_value = "L"; break;
          case "13" : $rand_value = "M"; break;
          case "14" : $rand_value = "N"; break;
          case "15" : $rand_value = "O"; break;
          case "16" : $rand_value = "P"; break;
          case "17" : $rand_value = "Q"; break;
          case "18" : $rand_value = "R"; break;
          case "19" : $rand_value = "S"; break;
          case "20" : $rand_value = "T"; break;
          case "21" : $rand_value = "U"; break;
          case "22" : $rand_value = "V"; break;
          case "23" : $rand_value = "W"; break;
          case "24" : $rand_value = "X"; break;
          case "25" : $rand_value = "Y"; break;
          case "26" : $rand_value = "Z"; break;
          case "27" : $rand_value = "0"; break;
          case "28" : $rand_value = "1"; break;
          case "29" : $rand_value = "2"; break;
          case "30" : $rand_value = "3"; break;
          case "31" : $rand_value = "4"; break;
          case "32" : $rand_value = "5"; break;
          case "33" : $rand_value = "6"; break;
          case "34" : $rand_value = "7"; break;
          case "35" : $rand_value = "8"; break;
          case "36" : $rand_value = "9"; break;
      }
      return $rand_value;
  }
}