# Vehicle Sales Management System - Codeigniter

Vehicle Sales Management System Built on CodeIgniter 2.x Framework

#Features : 
Front End with Vehicles Added from Back-end with details
Back-end login system for admins, employees
Different Controlling for Admin and Employee
New Employee Adding for doing Sales , Adding new vehicles

	Admin Features : # Add, Edit , Delete almost anything(Including new users), Sell vehicles, See customer Details
	Employee Features : # Add vehicles only and Sell them to new clients with their details
	-------------------------------------------------------------------------
	Others : Used CodeIgniter Active record for DB query, Basic Parser use of codeigniter, 
	uses cool template for backend with a lot 	 of effects, form validation with codeigniter Database is included in the folder.
	Uses Datatables with sorting , filtering , and date to date range for getting result
	Do change the database config to run on your server / localhost

Template has been used for back-end and front end 
More customization coming in future
Added Web.config file setting in-case you want to host this on Azure account 

See the software working live : 
http://voidthemes.com/scripts/vsmspro/

Admin User : admin@admin.com
Password : admin

Employee User : employee@employee.com
Password : employee

Video Tutorial for config : https://www.youtube.com/watch?v=F4uyw47OlJI

Visit our site : http://voidthemes.com 


If you want more customized option / The Pro Version don't hesitate to contact me here or on : dranger2011@gmail.com


By- Soyket Chowdhury, AIUB, CSE
